# Weekly Program Status

**Reporting period:**  
**Overall status:** Green / Amber / Red

## Executive summary
- What changed?
- What is the forecast?
- What decision or help is needed?

## Scorecard
| Area | Status | Evidence / commentary |
|---|---|---|
| Schedule | | |
| Scope | | |
| Quality | | |
| Risk | | |
| Resources | | |
| Handover | | |

## Completed this period
- 

## Planned next period
- 

## Top risks / issues
| ID | Impact | Owner | Next action | Due date |
|---|---|---|---|---|

## Decisions required
| Decision | Options | Recommendation | Decision owner | Needed by |
|---|---|---|---|---|
