# RAID Log — Sample

RAID means Risks, Assumptions, Issues, and Dependencies. The CSV in `data/raid_log.csv` is the working tracker.

## Review rules
- Every item has a unique ID, owner, due date, impact, and next action.
- Review high-priority items weekly and daily during active cutovers.
- Escalate any item that threatens a stage gate, safety/security approval, or critical path.
- Close an item only when evidence is recorded.

## Sample high-priority items
| ID | Type | Item | Response |
|---|---|---|---|
| R-01 | Risk | Equipment delivery may slip beyond the planned wave start | Confirm supplier dates; identify approved contingency stock |
| R-02 | Risk | Site access approvals may not be complete in time | Validate access at readiness gate; assign local owner |
| I-01 | Issue | Pilot test evidence is incomplete for one acceptance criterion | Assign technical owner and retest before wave approval |
| D-01 | Dependency | Operations team must approve support runbook before handover | Book review early and track sign-off as a milestone |

These are fictional examples, not real AFNET risks or conditions.
