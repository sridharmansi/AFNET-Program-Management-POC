# Roadmap and Stage Gates

## Illustrative 2-quarter roadmap

| Phase | Timing | Key activities | Exit criteria |
|---|---|---|---|
| 1. Mobilize | Weeks 1–2 | Confirm outcomes, governance, scope, roles | Charter and stakeholder map approved |
| 2. Assess & plan | Weeks 3–5 | Site readiness, dependency mapping, schedule baseline | Readiness checklist and baseline approved |
| 3. Pilot | Weeks 6–7 | Deploy to 2 representative pilot sites, test process | Pilot acceptance and lessons learned |
| 4. Wave 1 | Weeks 8–10 | Deploy 8 sites, daily triage, validate handover | 8 sites accepted; no unresolved critical blocker |
| 5. Wave 2 | Weeks 11–13 | Deploy 8 sites, apply improvements | 16 cumulative sites accepted |
| 6. Wave 3 | Weeks 14–16 | Deploy final 8 sites | 24 sites accepted |
| 7. Stabilize & close | Weeks 17–18 | Hypercare, operational handover, retrospective | Support sign-off and closure report |

## Critical stage gates
1. **Plan baseline:** sponsor accepts scope, schedule, assumptions, and target measures.
2. **Pilot go/no-go:** prerequisites verified; rollback and support plans approved.
3. **Site readiness:** access, resources, change window, approvals, and test plan confirmed.
4. **Cutover go/no-go:** acceptance criteria, rollback decision, and escalation contacts are ready.
5. **Operational acceptance:** monitoring, runbooks, ownership, and training are complete.

## Dependency logic
- Delivery readiness depends on equipment, site access, approved change windows, and required reviews.
- Cutover depends on completed installation checks and test evidence.
- Closure depends on defect disposition, documentation, training, and operational acceptance.
