# Program Charter

## 1. Program overview
**Program:** Secure Network Modernization & Multi-Site Deployment (fictional portfolio scenario)  
**Sponsor:** Executive Technology Steering Committee  
**Program Manager:** Program Management Office  
**Duration:** 2 quarters (illustrative)  
**Scope size:** 24 sites across 3 rollout waves (illustrative)

## 2. Business need
The organization needs a repeatable, governed way to modernize network services while minimizing disruption, validating readiness before cutover, and ensuring the operations team can support the delivered solution.

## 3. Objectives
- Deliver approved scope through controlled rollout waves.
- Improve consistency of readiness, testing, and acceptance evidence.
- Surface risks and dependencies early enough for action.
- Provide leaders with a concise, evidence-based view of schedule, scope, quality, and decisions.
- Complete operational handover for every site.

## 4. In scope
- Site readiness checklist and readiness reviews
- Schedule, dependency, resource, and vendor coordination
- Pilot planning and lessons learned
- Installation coordination and integration testing
- Cutover readiness, go/no-go governance, hypercare
- Training, documentation, and operations handover
- Program reporting and change control

## 5. Out of scope
- Publishing real network design or security implementation details
- Changes to live systems as part of this portfolio demonstration
- Procurement commitments or actual vendor contracts
- Any real AFNET site-specific or classified information

## 6. Success measures
| Measure | Target | Evidence |
|---|---:|---|
| Site rollout completion | 24/24 sites | Accepted site records |
| First-pass acceptance | >=95% | Test and acceptance records |
| Schedule variance | Within 10 business days | Baseline vs actual milestones |
| High-priority risk ownership | 100% have owner and due date | RAID review |
| Handover completion | 100% of accepted sites | Runbook, training, support sign-off |

Targets are illustrative for the POC and must be baselined with real stakeholders in a real program.

## 7. Governance
- **Weekly program review:** schedule, RAID, budget/resource trends, decisions needed.
- **Fortnightly steering committee:** escalations, scope changes, cross-functional trade-offs.
- **Daily rollout stand-up during cutover waves:** readiness, blockers, next 24-hour plan.
- **Go/no-go review:** objective evidence required before each site cutover.

## 8. Roles
- Sponsor: accountable for strategic outcomes and escalations.
- Program Manager: integrated plan, governance, decisions, stakeholder alignment.
- Technical Lead: technical design authority and test strategy.
- Site Lead: local readiness and deployment coordination.
- Security/Compliance Lead: required reviews and evidence.
- Operations Lead: support model, monitoring, handover acceptance.
- Vendor/Delivery Lead: delivery commitments, installation resources, defect closure.

## 9. Key assumptions and constraints
- Site access and local contacts are available before scheduled work.
- Required equipment and approved configurations arrive before deployment.
- Security approvals and change windows are confirmed ahead of cutover.
- Operations staff are available for training and handover.
- Illustrative dates and metrics are not actual AFNET data.
