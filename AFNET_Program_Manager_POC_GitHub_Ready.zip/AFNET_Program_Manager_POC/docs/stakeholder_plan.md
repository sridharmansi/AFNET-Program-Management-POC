# Stakeholder & Communication Plan

| Stakeholder group | Primary concern | Cadence | Format | Owner |
|---|---|---|---|---|
| Executive sponsor / steering committee | Outcomes, timeline, major risks, decisions | Fortnightly | 1-page scorecard + decision log | Program Manager |
| Technical leads | Design dependencies, test readiness, defects | Weekly; daily during rollout | Working session / blocker list | Technical Lead |
| Site coordinators | Access, readiness, local schedule, user impact | Weekly; daily during cutover | Checklist + short stand-up | Site Lead |
| Security/compliance | Required reviews and evidence | At gates and on change | Evidence checklist | Security Lead |
| Vendor/delivery partners | Supply, staffing, commitments, issue resolution | Weekly | Delivery review | Vendor Lead |
| Operations/support | Handover, monitoring, runbooks, training | Weekly from pilot onward | Handover checklist | Operations Lead |
| End-user representatives | Impact, communications, acceptance | Before each wave | Briefing / feedback form | Change Lead |

## Communication principles
- Share a single source of truth for schedule, RAID, decisions, and site status.
- Separate facts, forecasts, risks, and decisions needed.
- Escalate a critical blocker as soon as its impact is understood; do not wait for the weekly meeting.
- Record decisions with owner, date, rationale, and downstream impact.
- Tailor detail to the audience while keeping metrics consistent.
