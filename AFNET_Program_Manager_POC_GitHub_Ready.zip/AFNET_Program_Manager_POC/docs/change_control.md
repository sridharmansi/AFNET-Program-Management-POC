# Change Control

## Change intake
A change request must include:
- Request ID and requestor
- Description and reason
- Impact on scope, schedule, cost, risk, security/compliance, and operations
- Options considered and recommendation
- Required decision date
- Approver and decision record

## Workflow
1. Log the request in the decision/change register.
2. Program Manager checks completeness and assigns impact analysis.
3. Technical, security, operations, and delivery owners assess the request.
4. Program Manager presents options and trade-offs to the authorized approver.
5. Record approve/reject/defer decision, rationale, owner, and date.
6. Update baseline, risks, dependencies, and communications if approved.

## Guardrails
No unapproved scope changes are treated as committed work. Any security- or compliance-relevant change follows the applicable formal approval process.
