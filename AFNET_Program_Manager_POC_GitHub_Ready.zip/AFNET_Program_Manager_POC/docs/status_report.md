# Weekly Program Status — Example

**Reporting period:** Illustrative Week 10  
**Overall status:** AMBER (sample only)

## Executive summary
The program is progressing through Wave 1. Most planned activities are on track, but two sites need additional readiness evidence before cutover. The team is protecting acceptance quality by holding those sites at the readiness gate rather than compressing validation.

## Sample scorecard
| Area | Status | Commentary |
|---|---|---|
| Schedule | Amber | Two site readiness dependencies need resolution |
| Scope | Green | No approved scope change in this sample period |
| Quality | Green | Acceptance checklist is being applied consistently |
| Risk | Amber | Supplier date confirmation remains a watch item |
| Operations handover | Green | Runbook review is scheduled before wave completion |

## Progress this period
- Completed readiness reviews for the planned Wave 1 sites.
- Held a cross-functional dependency review.
- Confirmed acceptance evidence owners for the next cutover window.

## Next period
- Resolve readiness gaps for the two held sites.
- Reconfirm equipment delivery dates.
- Complete the next go/no-go review.

## Decisions needed
- Confirm whether contingency resources can be reserved if the supplier date slips.

## Top risks / blockers
1. Delivery timing may affect the wave sequence.
2. Incomplete site prerequisites could push cutover dates.

**Note:** This is a fictional example for portfolio demonstration.
