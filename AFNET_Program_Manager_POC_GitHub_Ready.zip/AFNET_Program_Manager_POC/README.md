# AFNET Modernization & Deployment — Program Manager POC

> **Portfolio demonstration project.** This is a fictionalized, sanitized program-management case study inspired by large-scale secure network deployment programs. It does not contain actual AFNET architecture, locations, configurations, operational data, or classified/proprietary information.

## Executive summary
This POC demonstrates how a Program Manager can plan and govern a multi-site secure-network modernization program using clear milestones, measurable outcomes, dependency management, risk controls, stakeholder communication, and data-driven reporting.

**Scenario:** A fictional organization is upgrading connectivity and network services across 24 sites in 3 rollout waves. The program includes readiness assessments, equipment delivery, installation, integration testing, user acceptance, cutover, and hypercare.

## Outcomes targeted
- Deliver all 24 sites through controlled rollout waves.
- Maintain at least 95% first-pass site acceptance.
- Keep critical-path milestone variance within 10 business days.
- Close high-priority risks with named owners and due dates.
- Complete handover with support ownership, runbooks, and training.

*All targets and sample data are illustrative, not actual AFNET performance.*

## What this repository contains
| Artifact | Purpose |
|---|---|
| `docs/program_charter.md` | Business case, scope, success measures, governance |
| `docs/roadmap.md` | Phases, milestones, and stage gates |
| `docs/stakeholder_plan.md` | Stakeholder map and communication cadence |
| `docs/RAID_log.md` | Risks, assumptions, issues, dependencies |
| `docs/change_control.md` | Change intake and decision workflow |
| `docs/status_report.md` | Example executive weekly update |
| `data/milestones.csv` | Sample schedule and milestone status |
| `data/raid_log.csv` | Structured RAID tracker |
| `data/site_rollout.csv` | Fictional site rollout tracker |
| `data/kpi_snapshot.csv` | Sample metrics for a dashboard |
| `templates/weekly_status_template.md` | Reusable weekly status template |
| `templates/decision_log.csv` | Decision register template |

## Program approach
1. **Align:** confirm outcomes, scope, stakeholders, and acceptance criteria.
2. **Plan:** baseline schedule, resource needs, dependencies, and rollout waves.
3. **Prove readiness:** validate prerequisites and pilot the deployment process.
4. **Deploy in waves:** use go/no-go gates and daily issue triage.
5. **Stabilize:** monitor service health, resolve defects, and transition to operations.
6. **Learn:** capture lessons and update the rollout playbook.

## Example KPIs
- Site readiness completion
- Deployment completion versus baseline
- First-pass acceptance rate
- Open high-severity risks/issues
- Change failure rate
- Mean time to resolve deployment blockers
- Training and handover completion

## How to use this as a GitHub portfolio project
1. Create a public repository using a safe name such as `secure-network-program-management-poc`.
2. Upload these files; keep the disclaimer in the README.
3. Add a screenshot of a dashboard only if you create one from this fictional data.
4. In interviews, explain the decisions, trade-offs, governance, and metrics—not just the documents.
5. Replace illustrative numbers only with information you are authorized to disclose.

## Interview talking points
- How would you sequence sites when readiness and business criticality differ?
- What is your escalation threshold for a critical-path dependency?
- How do you keep engineering, field teams, vendors, security, and operations aligned?
- What evidence is required to approve a site for cutover?
- How do you distinguish activity completion from measurable business outcomes?

## Important confidentiality note
Do not publish real network diagrams, IP addresses, topology, security controls, site names, vulnerabilities, credentials, operational schedules, or any non-public AFNET details. This repository is deliberately generic and uses fictional sample data.
